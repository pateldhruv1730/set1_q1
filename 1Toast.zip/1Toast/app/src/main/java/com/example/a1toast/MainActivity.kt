package com.example.a1toast

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
     var btns:Button = findViewById(R.id.btnShow)
        btns.setOnClickListener {

            var edtext:EditText = findViewById(R.id.edName)

            var entText = edtext.text.toString()
            var mytoast = Toast.makeText(this,entText,Toast.LENGTH_LONG)
            mytoast.setGravity(Gravity.TOP,40,40)
            mytoast.show()

        }




    }

}